Sublime TypeScript Readme
----------------------------------------------------------------------------
Author: Microsoft Open Technologies, Inc.

TypeScript bundle for Sublime, this bundle provides syntax highlighting.

This is provided as a sample to help you get started coding with TypeScript in Sublime

## Feature
1. TypeScript language syntax highlighting 

## Installation
Installation instructions can be found here: http://docs.sublimetext.info